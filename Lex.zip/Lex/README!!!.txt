/**
 * Mrf4r1tZ
 */

=========[COMMAND]=========

1. HAPUS DATA TERMUX
2. EXTRACK FILE DI DALAM FOLDER DOWNLOADS
4. termux-setup-storage
   (Ijinkan aksess / Y)
5. cd storage/downloads/Lex
6. pkg install python
7. pkg install php
8. pip3 install -r https://blacknetid.pw/tools/allin1/termux/req.txt
9. python lex.py
10. Enjoy

===[THANKS FOR USING]===